import java.awt.Color;

import javax.swing.JFrame;
public class TicTacToeFront {
public static void main(String[]args) {
	TicTacToeFrontcons tc=new TicTacToeFrontcons();
	tc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	tc.getContentPane().setBackground(Color.yellow);
	tc.setSize(270,420);
	tc.setResizable(false);
    tc.setVisible(true);
}
}
